/* ============================================================
   EDUVEX AI — Frontend Engine v4.0
   Powered by Eduvex Labs™
   All API calls go through the backend (/api/*) — NO keys in frontend
   ============================================================ */
'use strict';

// ===== SECURITY: Block devtools in production =====
(function securityGuard(){
  document.addEventListener('contextmenu', e => e.preventDefault());
  document.addEventListener('keydown', e => {
    if (e.key==='F12' ||(e.ctrlKey&&e.shiftKey&&['I','J','C'].includes(e.key))||(e.ctrlKey&&e.key==='U')) e.preventDefault();
  });
  // Console banner
  setTimeout(()=>{
    console.log('%c⚠️ STOP!','color:red;font-size:32px;font-weight:900;');
    console.log('%cThis is Eduvex AI — Eduvex Labs™. Do not paste anything here.','color:#6c63ff;font-size:14px;');
  }, 500);
})();

// ===== STATE =====
const S = {
  user: null, token: null,
  currentChatId: null, messages: [],
  isLoading: false, webSearch: false,
  attachedImage: null, recognition: null,
  synthesis: window.speechSynthesis,
  currentModel: 'Eduvex Ultra',
  voiceOn: false, adminToken: null,
};

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  loadTheme();
  initVoice();
  autoResize(document.getElementById('msgInput'));
  checkSession();
  // Admin shortcut: URL ?admin=1
  if (new URLSearchParams(location.search).get('admin')==='1') openAdminLogin();
});

// ===== SESSION =====
async function checkSession(){
  const token = getCookie('eduvex_token') || localStorage.getItem('eduvex_token');
  if (!token){ showView('landingView'); return; }
  S.token = token;
  try {
    const r = await api('/api/auth/me');
    S.user  = r.user;
    enterApp();
  } catch(e){ clearSession(); showView('landingView'); }
}

function clearSession(){
  S.user=null; S.token=null;
  localStorage.removeItem('eduvex_token');
  document.cookie='eduvex_token=;max-age=0;path=/';
}

// ===== API HELPER (all backend calls) =====
async function api(url, method='GET', body=null, isFormData=false){
  const opts = { method, credentials:'include',
    headers: S.token && !isFormData ? { Authorization:`Bearer ${S.token}` } : (S.token ? { Authorization:`Bearer ${S.token}` } : {}) };
  if (body && !isFormData){
    opts.headers['Content-Type']='application/json';
    opts.body = JSON.stringify(body);
  } else if (body && isFormData){
    opts.body = body; // FormData — no Content-Type header
  }
  const resp = await fetch(url, opts);
  if (resp.status===401){ clearSession(); showView('landingView'); throw new Error('Unauthorized'); }
  const data = await resp.json().catch(()=>({}));
  if (!resp.ok) throw new Error(data.error || `HTTP ${resp.status}`);
  return data;
}

// ===== VIEWS =====
function showView(id){
  document.querySelectorAll('.auth-view').forEach(v => v.classList.remove('active'));
  const el = document.getElementById(id);
  if (el) el.classList.add('active');
}

// ===== AUTH =====
async function handleLogin(e){
  e.preventDefault();
  const btn=document.getElementById('loginBtn'), tx=document.getElementById('loginBtnTx');
  const email=v('loginEmail'), pass=v('loginPass');
  showAuthMsg('loginMsg','','');
  setBtn(btn,tx,'<span class="fl-spinner" style="width:16px;height:16px;border-width:2px;display:inline-block;margin-right:.4rem"></span> লগইন হচ্ছে…', true);
  try {
    const r = await api('/api/auth/login','POST',{email,password:pass});
    S.user=r.user; S.token=r.token;
    localStorage.setItem('eduvex_token', r.token);
    enterApp();
  } catch(err){ showAuthMsg('loginMsg', err.message,'err'); }
  finally { setBtn(btn,tx,'<i class="fas fa-sign-in-alt"></i> লগইন করুন', false); }
}

async function handleSignup(e){
  e.preventDefault();
  const btn=document.getElementById('signupBtn'), tx=document.getElementById('signupBtnTx');
  const name=v('su_name'),age=v('su_age'),district=v('su_district'),school=v('su_school'),className=v('su_class'),email=v('su_email'),password=v('su_pass');
  showAuthMsg('signupMsg','','');
  if (!district||!className){ showAuthMsg('signupMsg','জেলা এবং ক্লাস বেছে নিন','err'); return; }
  setBtn(btn,tx,'<span class="fl-spinner" style="width:16px;height:16px;border-width:2px;display:inline-block;margin-right:.4rem"></span> তৈরি হচ্ছে…', true);
  try {
    const r = await api('/api/auth/signup','POST',{name,age,district,school,className,email,password});
    S.user=r.user; S.token=r.token;
    localStorage.setItem('eduvex_token', r.token);
    enterApp();
    toast('স্বাগতম! '+name+' 🎓','success');
  } catch(err){ showAuthMsg('signupMsg', err.message,'err'); }
  finally { setBtn(btn,tx,'<i class="fas fa-user-plus"></i> অ্যাকাউন্ট তৈরি করুন', false); }
}

function showAuthMsg(id, msg, type){
  const el=document.getElementById(id); if(!el) return;
  el.innerHTML=msg; el.className='auth-msg'+(type?' '+type:'');
}

async function logout(){
  try { await api('/api/auth/logout','POST'); } catch(e){}
  clearSession();
  document.getElementById('mainApp').style.display='none';
  document.getElementById('authOverlay').style.display='';
  showView('landingView');
  closeModal('profileBackdrop');
  toast('লগআউট সফল','success');
}

// ===== ENTER APP =====
function enterApp(){
  document.getElementById('authOverlay').style.display='none';
  document.getElementById('mainApp').style.display='flex';
  const u=S.user;
  if(!u) return;
  const init=(u.name||'?').charAt(0).toUpperCase();
  ['sbAvatar','modalAvatar','profileAvatar'].forEach(id=>{ const e=document.getElementById(id); if(e) e.textContent=init; });
  ['sbName'].forEach(id=>{ const e=document.getElementById(id); if(e) e.textContent=u.name||'শিক্ষার্থী'; });
  ['sbClass'].forEach(id=>{ const e=document.getElementById(id); if(e) e.textContent=u.className||''; });
  document.getElementById('welcomeGreet').textContent=`হ্যালো ${u.name||'বন্ধু'}! আমি Eduvex AI 👋`;
  loadChatList();
}

// ===== THEME =====
function loadTheme(){
  const t=localStorage.getItem('eduvex_theme')||'dark';
  document.documentElement.setAttribute('data-theme',t);
  updateThemeBtn(t);
}
function toggleTheme(){
  const c=document.documentElement.getAttribute('data-theme');
  const n=c==='dark'?'light':'dark';
  document.documentElement.setAttribute('data-theme',n);
  localStorage.setItem('eduvex_theme',n);
  updateThemeBtn(n);
}
function updateThemeBtn(t){
  const b=document.getElementById('themeBtn'); if(!b) return;
  b.innerHTML=t==='dark'?'<i class="fas fa-sun"></i>':'<i class="fas fa-moon"></i>';
}
function togglePass(id,btn){ const i=document.getElementById(id); if(!i) return; i.type=i.type==='password'?'text':'password'; btn.innerHTML=i.type==='password'?'<i class="fas fa-eye"></i>':'<i class="fas fa-eye-slash"></i>'; }

// ===== CHAT LIST =====
async function loadChatList(){
  try {
    const r = await api('/api/chats');
    renderChatList(r.chats||[]);
  } catch(e){ console.error('loadChatList:',e); }
}

function renderChatList(chats, filter=''){
  const container=document.getElementById('chatListContainer');
  const empty=document.getElementById('chatEmpty');
  container.querySelectorAll('.chat-group-label,.chat-item').forEach(e=>e.remove());
  const filtered = filter ? chats.filter(c=>(c.title||'').toLowerCase().includes(filter.toLowerCase())) : chats;
  if(!filtered.length){ if(empty) empty.style.display=''; return; }
  if(empty) empty.style.display='none';

  const today=new Date().toDateString(), yest=new Date(Date.now()-864e5).toDateString();
  const groups={'আজ':[],'গতকাল':[],'আগে':[]};
  filtered.forEach(c=>{
    const d=new Date(c.updatedAt||c.createdAt).toDateString();
    if(d===today) groups['আজ'].push(c);
    else if(d===yest) groups['গতকাল'].push(c);
    else groups['আগে'].push(c);
  });

  Object.entries(groups).forEach(([lbl,items])=>{
    if(!items.length) return;
    const gl=document.createElement('div'); gl.className='chat-group-label'; gl.textContent=lbl;
    container.appendChild(gl);
    items.forEach(c=>{
      const div=document.createElement('div');
      div.className='chat-item'+(c._id===S.currentChatId?' active':'');
      div.innerHTML=`<i class="fas fa-message ci-icon"></i>
        <div class="ci-tx"><div class="ci-title">${esc(c.title||'নতুন চ্যাট')}</div><div class="ci-time">${timeAgo(c.updatedAt||c.createdAt)}</div></div>
        <button class="ci-del" onclick="deleteChat('${c._id}',event)" title="মুছুন"><i class="fas fa-trash"></i></button>`;
      div.onclick=(e)=>{ if(!e.target.closest('.ci-del')) openChat(c._id); };
      container.appendChild(div);
    });
  });
}

function filterChats(val){ loadChatList().then(()=>{}); /* re-render with filter via client-side */ }

async function openChat(chatId){
  S.currentChatId=chatId;
  hideWelcome();
  document.getElementById('messagesContainer').innerHTML='';
  document.querySelectorAll('.chat-item').forEach(i=>{ i.classList.toggle('active', i.querySelector('.ci-del')?.getAttribute('onclick')?.includes(chatId)||false); });
  try {
    const r = await api(`/api/chats/${chatId}/messages`);
    S.messages=(r.messages||[]).map(m=>({role:m.role,content:m.content,image:m.hasImage?true:null,id:m._id,time:m.createdAt}));
    S.messages.forEach(m=>renderMsg(m));
    scrollBottom();
    // Update active state
    document.querySelectorAll('.chat-item').forEach(it=>{
      const del=it.querySelector('.ci-del'); if(!del) return;
      it.classList.toggle('active', del.getAttribute('onclick')?.includes(chatId)||false);
    });
  } catch(e){ toast('চ্যাট লোড ব্যর্থ','error'); }
  if(window.innerWidth<768) closeSidebar();
}

async function startNewChat(){
  S.currentChatId=null; S.messages=[];
  document.getElementById('messagesContainer').innerHTML='';
  showWelcome();
  document.querySelectorAll('.chat-item').forEach(i=>i.classList.remove('active'));
  document.getElementById('msgInput').focus();
  if(window.innerWidth<768) closeSidebar();
}

async function deleteChat(id, e){
  e.stopPropagation();
  try {
    await api(`/api/chats/${id}`,'DELETE');
    if(S.currentChatId===id){ S.currentChatId=null; document.getElementById('messagesContainer').innerHTML=''; showWelcome(); }
    loadChatList();
    toast('চ্যাট মুছে ফেলা হয়েছে','success');
  } catch(err){ toast('মুছতে ব্যর্থ','error'); }
}

// ===== SEND MESSAGE =====
async function sendMsg(){
  const input=document.getElementById('msgInput');
  const text=input.value.trim();
  if((!text && !S.attachedImage)||S.isLoading) return;
  if(isHarmful(text)){ toast('⚠️ এই ধরনের প্রশ্ন করা যাবে না','error'); return; }

  input.value=''; input.style.height='auto'; updateCount();
  hideWelcome();

  // Create chat if new
  if(!S.currentChatId){
    try {
      const r = await api('/api/chats','POST',{ title: text.substring(0,50)||(S.attachedImage?'ছবি বিশ্লেষণ':'নতুন চ্যাট') });
      S.currentChatId=r.chat._id;
      loadChatList();
    } catch(e){ toast('চ্যাট তৈরি ব্যর্থ','error'); return; }
  }

  // Render user message immediately
  const userMsgId='u_'+Date.now();
  const userMsg={id:userMsgId,role:'user',content:text,image:S.attachedImage,time:new Date().toISOString()};
  S.messages.push(userMsg); renderMsg(userMsg); scrollBottom();

  // Show typing
  showTyping(); S.isLoading=true;
  document.getElementById('sendBtn').disabled=true;

  // Build FormData
  const fd=new FormData();
  fd.append('content', text);
  fd.append('webSearch', String(S.webSearch));
  if(S.attachedImage) fd.append('image', S.attachedImage);
  const imgPreview=S.attachedImage;
  clearAttachments();

  try {
    const r = await api(`/api/chats/${S.currentChatId}/messages`,'POST',fd,true);
    hideTyping();

    const aiMsg={id:r.aiMessage._id,role:'assistant',content:r.aiMessage.content,time:r.aiMessage.createdAt,searchResults:r.aiMessage.searchResults};
    S.messages.push(aiMsg); renderMsg(aiMsg); scrollBottom();
    loadChatList();

    // Voice output
    if(localStorage.getItem('eduvex_voice')==='on') speakText(r.aiMessage.content);

  } catch(err){
    hideTyping();
    const errMsg={id:'e_'+Date.now(),role:'assistant',content:`⚠️ দুঃখিত! কিছু সমস্যা হয়েছে।\n\n_${err.message}_`,time:new Date().toISOString()};
    S.messages.push(errMsg); renderMsg(errMsg); scrollBottom();
  }

  S.isLoading=false;
  document.getElementById('sendBtn').disabled=false;
}

function askSuggestion(text){ document.getElementById('msgInput').value=text; sendMsg(); }

// ===== HARMFUL FILTER =====
function isHarmful(txt){
  return /bomb|weapon|drug|hack.*exploit|malware|suicide.*method|murder.*how|rape|csam|child.?porn|terrorist.*attack/i.test(txt||'') ||
         /বোমা.*বানা|মাদক.*কোথায়|আত্মহত্যা.*পদ্ধতি|ধর্ষণ.*কীভাবে/i.test(txt||'');
}

// ===== RENDER MESSAGE =====
function renderMsg(msg){
  const container=document.getElementById('messagesContainer');
  const wrap=document.createElement('div');
  wrap.className=`msg-wrap ${msg.role==='user'?'user':'ai'}`;
  wrap.id='msg_'+msg.id;

  const initials=msg.role==='user'?(S.user?.name?.charAt(0)||'U'):'E';
  const timeStr=msg.time?new Date(msg.time).toLocaleTimeString('bn-BD',{hour:'2-digit',minute:'2-digit'}):'';

  let bubbleHtml='';
  if(msg.image && typeof msg.image==='string' && msg.image.startsWith('data:')){
    bubbleHtml+=`<img src="${msg.image}" class="msg-img" onclick="previewImg('${msg.image}')" alt="attached"/>`; 
  }
  if(msg.content){
    // Security check: never show system prompt if leaked
    let safe=msg.content.replace(/\[SYSTEM\][\s\S]*?\[\/SYSTEM\]/gi,'[System content hidden]');
    let rendered='';
    try { rendered=marked.parse(safe); } catch(e){ rendered=esc(safe).replace(/\n/g,'<br>'); }
    // Highlight code blocks
    bubbleHtml+=rendered;
  }
  if(msg.searchResults?.length){
    bubbleHtml=`<div class="search-banner"><i class="fas fa-globe"></i> Web search মিলিয়ে উত্তর তৈরি হয়েছে (${msg.searchResults.length} sources)</div>`+bubbleHtml;
  }

  const actions=msg.role==='assistant'?`
    <div class="msg-actions">
      <button class="ma-btn" onclick="copyMsg('msg_${msg.id}')"><i class="fas fa-copy"></i> কপি</button>
      <button class="ma-btn" onclick="speakMsg('msg_${msg.id}')"><i class="fas fa-volume-up"></i> পড়ো</button>
      <button class="ma-btn" onclick="regenMsg()"><i class="fas fa-redo"></i> আবার</button>
    </div>`:'';

  wrap.innerHTML=`
    <div class="msg-av">${initials}</div>
    <div class="msg-content">
      <div class="msg-bubble">${bubbleHtml}</div>
      ${actions}
      <div class="msg-time">${timeStr}</div>
    </div>`;

  container.appendChild(wrap);
  // Highlight code
  wrap.querySelectorAll('pre code').forEach(el=>{ try{ hljs.highlightElement(el); }catch(e){} });
}

function previewImg(src){
  const overlay=document.createElement('div');
  overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:9999;display:flex;align-items:center;justify-content:center;cursor:pointer';
  overlay.innerHTML=`<img src="${src}" style="max-width:90vw;max-height:90vh;border-radius:12px;"/>`;
  overlay.onclick=()=>overlay.remove();
  document.body.appendChild(overlay);
}

function copyMsg(wrapId){ const el=document.getElementById(wrapId); if(!el) return; const txt=el.querySelector('.msg-bubble')?.innerText||''; navigator.clipboard.writeText(txt).then(()=>toast('কপি হয়েছে!','success')); }
function speakMsg(wrapId){ const el=document.getElementById(wrapId); if(!el) return; speakText(el.querySelector('.msg-bubble')?.innerText||''); }
async function regenMsg(){
  const lastUser=[...S.messages].reverse().find(m=>m.role==='user');
  if(!lastUser) return;
  const lastAi=[...S.messages].reverse().find(m=>m.role==='assistant');
  if(lastAi){ S.messages=S.messages.filter(m=>m.id!==lastAi.id); document.getElementById('msg_'+lastAi.id)?.remove(); }
  document.getElementById('msgInput').value=lastUser.content;
  sendMsg();
}

// ===== TYPING =====
function showTyping(){
  const c=document.getElementById('messagesContainer');
  const d=document.createElement('div'); d.id='typingWrap'; d.className='msg-wrap ai';
  d.innerHTML='<div class="msg-av">E</div><div class="msg-content"><div class="msg-bubble" style="padding:.8rem 1rem"><div class="typing-dots"><div class="td"></div><div class="td"></div><div class="td"></div></div></div></div>';
  c.appendChild(d); scrollBottom();
}
function hideTyping(){ document.getElementById('typingWrap')?.remove(); }

// ===== WELCOME / HIDE =====
function showWelcome(){ const w=document.getElementById('welcomeScreen'); if(w) w.style.display='flex'; }
function hideWelcome(){ const w=document.getElementById('welcomeScreen'); if(w) w.style.display='none'; }

// ===== SCROLL =====
function scrollBottom(){ const a=document.getElementById('chatArea'); if(a) setTimeout(()=>a.scrollTop=a.scrollHeight,60); }

// ===== SIDEBAR =====
function toggleSidebar(){
  const sb=document.getElementById('sidebar'), ov=document.getElementById('sbOverlay');
  if(window.innerWidth<768){ sb.classList.toggle('mobile-open'); ov.classList.toggle('active',sb.classList.contains('mobile-open')); }
  else sb.classList.toggle('collapsed');
}
function closeSidebar(){ document.getElementById('sidebar').classList.remove('mobile-open'); document.getElementById('sbOverlay').classList.remove('active'); }

// ===== MODEL MENU =====
function toggleModelMenu(){ const m=document.getElementById('modelMenu'); m.style.display=m.style.display==='none'?'block':'none'; }
function setModel(name, modelId){
  S.currentModel=name;
  document.getElementById('currentModelName').textContent=name;
  document.getElementById('topModelName').textContent=name;
  document.querySelectorAll('.mm-item').forEach(i=>i.classList.remove('active'));
  event?.target?.closest('.mm-item')?.classList.add('active');
  document.getElementById('modelMenu').style.display='none';
  toast('মডেল: '+name,'success');
}
document.addEventListener('click', e=>{ if(!e.target.closest('.model-menu')&&!e.target.closest('.model-selector-btn')&&!e.target.closest('.model-display')) document.getElementById('modelMenu').style.display='none'; });

// ===== WEB SEARCH =====
function toggleWebSearch(){
  S.webSearch=!S.webSearch;
  document.getElementById('webSearchBtn').classList.toggle('active',S.webSearch);
  toast(S.webSearch?'🌐 Web সার্চ চালু':'🌐 Web সার্চ বন্ধ','success');
}

// ===== IMAGE UPLOAD =====
function triggerImg(){ document.getElementById('imgInput').click(); }
function handleImg(e){
  const file=e.target.files[0]; if(!file) return;
  if(!file.type.startsWith('image/')){ toast('শুধু ছবি ফাইল দিন','error'); return; }
  if(file.size>8*1024*1024){ toast('ছবি ৮MB এর বেশি হতে পারবে না','error'); return; }
  S.attachedImage=file;
  const reader=new FileReader();
  reader.onload=ev=>{
    const atts=document.getElementById('attachments');
    atts.innerHTML=`<div class="att-preview"><img src="${ev.target.result}" alt=""/><button class="att-rm" onclick="clearAttachments()"><i class="fas fa-times"></i></button></div>`;
  };
  reader.readAsDataURL(file);
  e.target.value='';
}
function clearAttachments(){ S.attachedImage=null; document.getElementById('attachments').innerHTML=''; }

// ===== VOICE =====
function initVoice(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition; if(!SR) return;
  S.recognition=new SR();
  S.recognition.lang='bn-BD'; S.recognition.continuous=false; S.recognition.interimResults=true;
  S.recognition.onresult=e=>{ document.getElementById('msgInput').value=Array.from(e.results).map(r=>r[0].transcript).join(''); updateCount(); };
  S.recognition.onend=()=>{ S.voiceOn=false; document.getElementById('voiceBtn').classList.remove('recording'); document.getElementById('voiceInd').classList.remove('active'); };
  S.recognition.onerror=()=>{ S.voiceOn=false; document.getElementById('voiceBtn').classList.remove('recording'); document.getElementById('voiceInd').classList.remove('active'); };
}
function toggleVoice(){
  if(!S.recognition){ toast('এই ব্রাউজারে ভয়েস সাপোর্ট নেই','error'); return; }
  if(S.voiceOn){ stopVoice(); }
  else { S.recognition.lang='bn-BD'; S.recognition.start(); S.voiceOn=true; document.getElementById('voiceBtn').classList.add('recording'); document.getElementById('voiceInd').classList.add('active'); toast('কথা বলুন…','success'); }
}
function stopVoice(){ if(S.recognition) S.recognition.stop(); S.voiceOn=false; document.getElementById('voiceBtn').classList.remove('recording'); document.getElementById('voiceInd').classList.remove('active'); }
function speakText(text){
  if(!S.synthesis) return; S.synthesis.cancel();
  const clean=text.replace(/[#*`_\[\]()]/g,'').slice(0,800);
  const u=new SpeechSynthesisUtterance(clean); u.lang='bn-BD'; u.rate=0.92;
  const voices=S.synthesis.getVoices(); const bn=voices.find(v=>v.lang.startsWith('bn'))||voices.find(v=>v.lang.startsWith('hi'));
  if(bn) u.voice=bn; S.synthesis.speak(u);
}

// ===== INPUT HELPERS =====
function handleKey(e){ if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); sendMsg(); } }
function resizeInput(el){ el.style.height='auto'; el.style.height=Math.min(el.scrollHeight,200)+'px'; }
function updateCount(){ const i=document.getElementById('msgInput'),c=document.getElementById('charCount'); if(i&&c) c.textContent=i.value.length; }
function autoResize(el){ if(el){ el.addEventListener('input',()=>resizeInput(el)); } }

// ===== MODALS =====
function openModal(id){ document.getElementById(id)?.classList.add('active'); }
function closeModal(id){ document.getElementById(id)?.classList.remove('active'); }

function openProfileModal(){
  const u=S.user; if(!u) return;
  document.getElementById('modalAvatar').textContent=(u.name||'?').charAt(0).toUpperCase();
  document.getElementById('modalName').textContent=u.name||'';
  document.getElementById('modalEmail').textContent=u.email||'';
  const grid=document.getElementById('profileGrid');
  grid.innerHTML=[
    {l:'জেলা',v:u.district||'—'},{l:'ক্লাস',v:u.className||'—'},
    {l:'বয়স',v:u.age||'—'},{l:'প্রতিষ্ঠান',v:u.school||'—'},
    {l:'যোগদান',v:u.createdAt?new Date(u.createdAt).toLocaleDateString('bn-BD'):'—'},
    {l:'মোট চ্যাট',v:'—'},
  ].map(i=>`<div class="pg-item"><div class="pg-label">${i.l}</div><div class="pg-val">${esc(String(i.v))}</div></div>`).join('');
  openModal('profileBackdrop');
}

// ===== PDF =====
function openPdfModal(){ document.getElementById('pdfTitleInput').value='Eduvex AI নোটস — '+new Date().toLocaleDateString('bn-BD'); openModal('pdfBackdrop'); }
async function generatePDF(){
  closeModal('pdfBackdrop');
  document.getElementById('pdfLoader').style.display='flex';
  await sleep(600);
  try {
    const {jsPDF}=window.jspdf;
    const doc=new jsPDF({orientation:'p',unit:'mm',format:'a4'});
    const title=document.getElementById('pdfTitleInput').value||'Eduvex AI Notes';
    const extra=document.getElementById('pdfExtra').value;

    // Header
    doc.setFillColor(108,99,255); doc.rect(0,0,210,26,'F');
    doc.setTextColor(255,255,255); doc.setFontSize(18); doc.setFont('helvetica','bold');
    doc.text('Eduvex AI',14,14); doc.setFontSize(9); doc.setFont('helvetica','normal');
    doc.text('Powered by Eduvex Labs\u2122',14,21); doc.text(new Date().toLocaleDateString('en-GB'),160,21);

    doc.setTextColor(40,40,70); doc.setFontSize(15); doc.setFont('helvetica','bold');
    const tl=doc.splitTextToSize(title,180); doc.text(tl,14,36);
    let y=36+tl.length*7; doc.setDrawColor(108,99,255); doc.setLineWidth(0.4); doc.line(14,y,196,y); y+=6;

    const addTxt=(txt,bold=false,col=null)=>{
      if(col) doc.setTextColor(...col); else doc.setTextColor(50,50,70);
      doc.setFont('helvetica',bold?'bold':'normal'); doc.setFontSize(10);
      const ls=doc.splitTextToSize(txt.replace(/[#*`_~]/g,''),180);
      ls.forEach(l=>{ if(y>274){doc.addPage();y=18;} doc.text(l,14,y); y+=5.5; }); y+=2;
    };

    if(extra) addTxt(extra);

    if(S.messages.length){
      addTxt('── Chat History ──',true,[108,99,255]); y+=2;
      S.messages.forEach(m=>{
        addTxt((m.role==='user'?'You':'Eduvex AI')+':',true,m.role==='user'?[80,80,80]:[108,99,255]);
        addTxt((m.content||'').slice(0,800));
        y+=1;
      });
    }

    const pages=doc.getNumberOfPages();
    for(let i=1;i<=pages;i++){ doc.setPage(i); doc.setFontSize(7); doc.setTextColor(160,160,180); doc.text(`Eduvex AI \u2014 Eduvex Labs\u2122 | Page ${i}/${pages}`,14,290); }

    doc.save(title.replace(/[^a-zA-Z0-9\u0980-\u09FF ]/g,'').replace(/\s+/g,'_').slice(0,50)+'.pdf');
    toast('✅ PDF ডাউনলোড হয়েছে!','success');
  } catch(e){ toast('PDF Error: '+e.message,'error'); }
  document.getElementById('pdfLoader').style.display='none';
}

// ===== ADMIN =====
function openAdminLogin(){ openModal('adminLoginBackdrop'); }
async function adminLogin(){
  const email=v('adminEmail'), pass=v('adminPass');
  showAuthMsg('adminLoginMsg','','');
  try {
    const r=await api('/api/admin/login','POST',{email,password:pass});
    S.adminToken=r.token; localStorage.setItem('eduvex_admin_token',r.token);
    closeModal('adminLoginBackdrop'); showAdmin(); toast('Admin logged in','success');
  } catch(e){ showAuthMsg('adminLoginMsg',e.message,'err'); }
}
function closeAdmin(){ document.getElementById('adminPanel').style.display='none'; }
function showAdmin(){ document.getElementById('adminPanel').style.display='block'; adminTab('dashboard'); }

async function adminTab(tab){
  document.querySelectorAll('.anl').forEach(b=>b.classList.remove('active'));
  document.querySelector(`.anl[onclick="adminTab('${tab}')"]`)?.classList.add('active');
  const body=document.getElementById('adminBody');
  body.innerHTML='<div style="padding:2rem;text-align:center;color:var(--text3)"><div class="fl-spinner" style="margin:0 auto 1rem"></div>Loading…</div>';
  try {
    if(tab==='dashboard') await renderAdminDashboard(body);
    else if(tab==='apikeys') await renderAdminApiKeys(body);
    else if(tab==='users') await renderAdminUsers(body);
    else if(tab==='logs') await renderAdminLogs(body);
  } catch(e){ body.innerHTML='<div style="padding:2rem;color:var(--danger)">Error: '+e.message+'</div>'; }
}

async function renderAdminDashboard(body){
  const r=await adminApi('/api/admin/stats');
  body.innerHTML=`
  <div class="admin-grid4">
    <div class="astat"><div class="astat-n">${r.totalUsers}</div><div class="astat-l">Total Users</div></div>
    <div class="astat"><div class="astat-n">${r.todaySignups}</div><div class="astat-l">Today Signups</div></div>
    <div class="astat"><div class="astat-n">${r.todayLogins}</div><div class="astat-l">Today Logins</div></div>
    <div class="astat"><div class="astat-n">${r.totalApiCalls}</div><div class="astat-l">Total API Calls</div></div>
  </div>
  <div class="admin-section">
    <div class="admin-section-hd"><h3>📊 API Usage Breakdown</h3></div>
    <div class="admin-section-bd">
      <table class="admin-table"><thead><tr><th>Provider</th><th>Total Calls</th><th>Failures</th><th>Success Rate</th></tr></thead>
      <tbody>${Object.entries(r.apiBreakdown||{}).map(([p,d])=>`<tr>
        <td><span style="text-transform:capitalize;font-weight:600">${p}</span></td>
        <td>${d.calls}</td><td>${d.failures}</td>
        <td><span class="status-badge ${d.failures/Math.max(d.calls,1)<0.1?'sb-ok':'sb-err'}">${Math.round((1-d.failures/Math.max(d.calls,1))*100)}%</span></td>
      </tr>`).join('')||'<tr><td colspan="4" style="text-align:center;color:var(--text3)">No data yet</td></tr>'}</tbody></table>
    </div>
  </div>
  <div class="admin-section">
    <div class="admin-section-hd"><h3>👥 Recent Users (Last 10)</h3></div>
    <div class="admin-section-bd" style="overflow-x:auto">
      <table class="admin-table"><thead><tr><th>Name</th><th>Email</th><th>Class</th><th>District</th><th>Joined</th></tr></thead>
      <tbody>${(r.recentUsers||[]).map(u=>`<tr><td><b>${esc(u.name||'')}</b></td><td>${esc(u.email||'')}</td><td>${esc(u.className||'')}</td><td>${esc(u.district||'')}</td><td>${u.createdAt?new Date(u.createdAt).toLocaleDateString('en-GB'):''}</td></tr>`).join('')||'<tr><td colspan="5" style="text-align:center;color:var(--text3)">No users yet</td></tr>'}</tbody></table>
    </div>
  </div>`;
}

async function renderAdminApiKeys(body){
  const r=await adminApi('/api/admin/apikeys');
  const keys=r.keys||[];
  body.innerHTML=`
  <div class="admin-section">
    <div class="admin-section-hd"><h3>🔑 API Keys</h3><button class="admin-btn" onclick="showAddKeyForm()">+ Add Key</button></div>
    <div class="admin-section-bd">
      <div id="addKeyForm" style="display:none;background:var(--bg3);padding:1rem;border-radius:10px;margin-bottom:1rem">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.8rem;margin-bottom:.6rem">
          <select class="admin-input" id="newKeyProvider" style="margin:0">
            <option value="">Provider…</option>${(r.providers||[]).map(p=>`<option value="${p}">${p}</option>`).join('')}
          </select>
          <input class="admin-input" id="newKeyLabel" placeholder="Label (e.g. Primary)" style="margin:0"/>
        </div>
        <input class="admin-input" id="newKeyVal" placeholder="API Key" type="password"/>
        <div style="display:flex;gap:.6rem">
          <button class="admin-btn success" onclick="saveNewKey()">💾 Save</button>
          <button class="admin-btn" onclick="testNewKey()">🧪 Test</button>
          <button class="admin-btn" style="background:var(--bg4)" onclick="document.getElementById('addKeyForm').style.display='none'">Cancel</button>
        </div>
        <div id="testResult" style="margin-top:.5rem;font-size:.8rem;color:var(--text2)"></div>
      </div>
      <div id="apiKeysList">
        ${keys.length?keys.map(k=>`
        <div class="api-card" id="apic_${k._id}">
          <div class="api-dot ${k.enabled?'ok':'off'}"></div>
          <div class="api-name">${esc(k.label||k.provider)}</div>
          <div class="api-provider">${k.provider}</div>
          <code style="font-size:.72rem;color:var(--text3)">${esc(k.key)}</code>
          <button class="toggle-sw ${k.enabled?'on':''}" onclick="toggleKey('${k._id}',this)" title="Enable/Disable"></button>
          <button class="admin-btn danger" style="padding:.32rem .7rem;font-size:.75rem" onclick="deleteKey('${k._id}')"><i class="fas fa-trash"></i></button>
        </div>`).join(''):`<div style="text-align:center;color:var(--text3);padding:1.5rem">No DB keys added yet. ENV keys are loaded automatically.</div>`}
      </div>
    </div>
  </div>`;
}

function showAddKeyForm(){ document.getElementById('addKeyForm').style.display='block'; }
async function saveNewKey(){
  const provider=v('newKeyProvider'), label=v('newKeyLabel'), key=v('newKeyVal');
  if(!provider||!key){ toast('Provider and key required','error'); return; }
  try { await adminApi('/api/admin/apikeys','POST',{provider,label,key}); toast('Key saved!','success'); adminTab('apikeys'); }
  catch(e){ toast(e.message,'error'); }
}
async function testNewKey(){
  const provider=v('newKeyProvider'), key=v('newKeyVal');
  document.getElementById('testResult').textContent='Testing…';
  try { const r=await adminApi('/api/admin/apikeys/test','POST',{provider,key}); document.getElementById('testResult').innerHTML=r.ok?'<span style="color:var(--accent)">✅ Key works!</span>':'<span style="color:var(--danger)">❌ Key failed</span>'; }
  catch(e){ document.getElementById('testResult').innerHTML='<span style="color:var(--danger)">Error: '+e.message+'</span>'; }
}
async function toggleKey(id, btn){
  const on=!btn.classList.contains('on');
  try { await adminApi(`/api/admin/apikeys/${id}`,'PATCH',{enabled:on}); btn.classList.toggle('on',on); const dot=btn.closest('.api-card')?.querySelector('.api-dot'); if(dot){dot.className='api-dot '+(on?'ok':'off');} toast(on?'Key enabled':'Key disabled','success'); }
  catch(e){ toast(e.message,'error'); }
}
async function deleteKey(id){
  if(!confirm('Delete this API key?')) return;
  try { await adminApi(`/api/admin/apikeys/${id}`,'DELETE'); toast('Key deleted','success'); adminTab('apikeys'); }
  catch(e){ toast(e.message,'error'); }
}

async function renderAdminUsers(body){
  const r=await adminApi('/api/admin/users');
  body.innerHTML=`<div class="admin-section">
    <div class="admin-section-hd"><h3>👥 All Users (${(r.users||[]).length})</h3>
      <button class="admin-btn" onclick="exportUsers()"><i class="fas fa-download"></i> Export CSV</button>
    </div>
    <div class="admin-section-bd" style="overflow-x:auto">
      <table class="admin-table"><thead><tr><th>Name</th><th>Email</th><th>Class</th><th>District</th><th>School</th><th>Age</th><th>Joined</th><th>Action</th></tr></thead>
      <tbody>${(r.users||[]).map(u=>`<tr>
        <td><b>${esc(u.name||'')}</b></td><td>${esc(u.email||'')}</td>
        <td>${esc(u.className||'')}</td><td>${esc(u.district||'')}</td>
        <td>${esc(u.school||'')}</td><td>${u.age||''}</td>
        <td>${u.createdAt?new Date(u.createdAt).toLocaleDateString('en-GB'):''}</td>
        <td><button class="admin-btn danger" style="padding:.28rem .6rem;font-size:.72rem" onclick="deleteUser('${u._id}')"><i class="fas fa-trash"></i></button></td>
      </tr>`).join('')||'<tr><td colspan="8" style="text-align:center;color:var(--text3)">No users yet</td></tr>'}</tbody></table>
    </div>
  </div>`;
}
async function deleteUser(id){ if(!confirm('Delete user?')) return; try { await adminApi(`/api/admin/users/${id}`,'DELETE'); toast('User deleted','success'); adminTab('users'); } catch(e){ toast(e.message,'error'); } }
function exportUsers(){ toast('Export feature — download via /api/admin/stats','success'); }

async function renderAdminLogs(body){
  const r=await adminApi('/api/admin/logs');
  const logs=r.logs||[];
  body.innerHTML=`<div class="admin-section">
    <div class="admin-section-hd"><h3>📋 API Logs</h3>
      <button class="admin-btn danger" onclick="clearLogs()"><i class="fas fa-trash"></i> Clear Logs</button>
    </div>
    <div class="admin-section-bd">
      <div class="log-area">${logs.length?logs.map(l=>`[${l.date}] ${l.provider} — ${l.calls} calls, ${l.failures} failures`).join('\n'):'No logs yet.'}</div>
    </div>
  </div>`;
}
async function clearLogs(){ try { await adminApi('/api/admin/logs','DELETE'); toast('Logs cleared','success'); adminTab('logs'); } catch(e){ toast(e.message,'error'); } }

async function adminApi(url, method='GET', body=null){
  const token=S.adminToken||localStorage.getItem('eduvex_admin_token')||'';
  const opts={ method, credentials:'include', headers:{ Authorization:`Bearer ${token}` } };
  if(body){ opts.headers['Content-Type']='application/json'; opts.body=JSON.stringify(body); }
  const resp=await fetch(url,opts);
  const data=await resp.json().catch(()=>({}));
  if(!resp.ok) throw new Error(data.error||`HTTP ${resp.status}`);
  return data;
}

// ===== HELPERS =====
function v(id){ const e=document.getElementById(id); return e?(e.value||'').trim():''; }
function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }
function getCookie(name){ const m=document.cookie.match(new RegExp('(?:^|; )'+name+'=([^;]*)')); return m?decodeURIComponent(m[1]):null; }
function setBtn(btn,tx,html,dis){ if(tx) tx.innerHTML=html; if(btn) btn.disabled=dis; }
function timeAgo(iso){ if(!iso) return ''; const ms=Date.now()-new Date(iso).getTime(),m=Math.floor(ms/6e4); if(m<1)return 'এইমাত্র'; if(m<60)return m+'m আগে'; const h=Math.floor(m/60); if(h<24)return h+'h আগে'; return Math.floor(h/24)+'d আগে'; }
function toast(msg,type='info'){ const t=document.getElementById('toast'),tx=document.getElementById('toastTx'); if(!t||!tx) return; t.className='toast show '+type; tx.textContent=msg; t.querySelector('i').className=type==='success'?'fas fa-check-circle':type==='error'?'fas fa-exclamation-circle':'fas fa-info-circle'; clearTimeout(window._toastT); window._toastT=setTimeout(()=>t.classList.remove('show'),3500); }

// Close modals on backdrop click
document.querySelectorAll('.modal-backdrop').forEach(b=>b.addEventListener('click',e=>{ if(e.target===b) b.classList.remove('active'); }));

// Android: ensure input always visible on keyboard open
if(/Android/i.test(navigator.userAgent)){
  const inp=document.getElementById('msgInput');
  if(inp) inp.addEventListener('focus',()=>setTimeout(()=>inp.scrollIntoView({block:'nearest'}),350));
}
