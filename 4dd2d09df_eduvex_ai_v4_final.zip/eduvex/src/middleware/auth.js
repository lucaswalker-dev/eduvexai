const jwt  = require('jsonwebtoken');
const db   = require('../models/db');

const JWT_SECRET = process.env.JWT_SECRET || 'EduvexAI_SecretKey_2026_Labs_Ultra_Secure_v4';

function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '30d' });
}

function verifyToken(token) {
  try { return jwt.verify(token, JWT_SECRET); }
  catch(e) { return null; }
}

function requireAuth(req, res, next) {
  const token = req.cookies?.eduvex_token || req.headers?.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  const payload = verifyToken(token);
  if (!payload) return res.status(401).json({ error: 'Invalid token' });
  const user = db.users.findById(payload.id);
  if (!user) return res.status(401).json({ error: 'User not found' });
  req.user = user;
  next();
}

function requireAdmin(req, res, next) {
  const token = req.cookies?.eduvex_admin_token || req.headers?.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  const payload = verifyToken(token);
  if (!payload || payload.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
  req.admin = payload;
  next();
}

module.exports = { signToken, verifyToken, requireAuth, requireAdmin };
