/**
 * Eduvex AI — Lightweight JSON Database (SQLite-free, zero native deps)
 * File-based persistent storage with in-memory caching
 */
const fs   = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '../../data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

class Collection {
  constructor(name) {
    this.name   = name;
    this.file   = path.join(DATA_DIR, `${name}.json`);
    this.data   = this._load();
  }

  _load() {
    try {
      if (fs.existsSync(this.file)) return JSON.parse(fs.readFileSync(this.file, 'utf8'));
    } catch(e) {}
    return {};
  }

  _save() {
    fs.writeFileSync(this.file, JSON.stringify(this.data, null, 2));
  }

  insert(doc) {
    const { v4: uuidv4 } = require('uuid');
    const id = doc._id || uuidv4();
    this.data[id] = { ...doc, _id: id, createdAt: doc.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() };
    this._save();
    return this.data[id];
  }

  findById(id) { return this.data[id] || null; }

  find(query = {}) {
    return Object.values(this.data).filter(doc => {
      return Object.entries(query).every(([k, v]) => doc[k] === v);
    });
  }

  findOne(query = {}) { return this.find(query)[0] || null; }

  update(id, update) {
    if (!this.data[id]) return null;
    this.data[id] = { ...this.data[id], ...update, updatedAt: new Date().toISOString() };
    this._save();
    return this.data[id];
  }

  delete(id) {
    if (!this.data[id]) return false;
    delete this.data[id];
    this._save();
    return true;
  }

  count(query = {}) { return this.find(query).length; }
  all() { return Object.values(this.data); }
}

const db = {
  users:    new Collection('users'),
  chats:    new Collection('chats'),
  messages: new Collection('messages'),
  apiKeys:  new Collection('apikeys'),
  logs:     new Collection('logs'),
  stats:    new Collection('stats'),
};

module.exports = db;
