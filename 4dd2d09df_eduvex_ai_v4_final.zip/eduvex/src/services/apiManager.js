/**
 * Eduvex AI — Intelligent Multi-API Manager
 * Handles all AI API providers with smart fallback, rotation, and load balancing
 */
const db = require('../models/db');

// ===== PROVIDER DEFINITIONS =====
const PROVIDERS = {
  openai: {
    name: 'OpenAI GPT-4o',
    baseUrl: 'https://api.openai.com/v1/chat/completions',
    models: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo'],
    defaultModel: 'gpt-4o-mini',
    visionModel: 'gpt-4o',
    type: 'openai',
  },
  gemini: {
    name: 'Google Gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/models',
    models: ['gemini-2.0-flash-exp', 'gemini-1.5-pro', 'gemini-1.5-flash'],
    defaultModel: 'gemini-2.0-flash-exp',
    type: 'gemini',
  },
  openrouter: {
    name: 'OpenRouter',
    baseUrl: 'https://openrouter.ai/api/v1/chat/completions',
    models: ['deepseek/deepseek-r1:free', 'meta-llama/llama-3.3-70b-instruct:free', 'qwen/qwen3-235b-a22b:free'],
    defaultModel: 'deepseek/deepseek-r1:free',
    type: 'openai',
  },
  deepseek: {
    name: 'DeepSeek',
    baseUrl: 'https://api.deepseek.com/v1/chat/completions',
    models: ['deepseek-chat', 'deepseek-reasoner'],
    defaultModel: 'deepseek-chat',
    type: 'openai',
  },
  cohere: {
    name: 'Cohere',
    baseUrl: 'https://api.cohere.ai/v1/chat',
    models: ['command-r-plus', 'command-r'],
    defaultModel: 'command-r-plus',
    type: 'cohere',
  },
  grok: {
    name: 'Grok (xAI)',
    baseUrl: 'https://api.x.ai/v1/chat/completions',
    models: ['grok-beta', 'grok-2'],
    defaultModel: 'grok-beta',
    type: 'openai',
  },
  aimlapi: {
    name: 'AIMLAPI',
    baseUrl: 'https://api.aimlapi.com/v1/chat/completions',
    models: ['gpt-4o', 'claude-3-opus-20240229'],
    defaultModel: 'gpt-4o',
    type: 'openai',
  },
};

// In-memory key state (rotation counters, failure tracking)
const keyState = {};

// ===== LOAD KEYS FROM DB + ENV =====
function loadKeys() {
  const keys = {};

  // Load from environment (hardcoded initial keys)
  const envKeys = [
    { provider:'openai',    key: process.env.OPENAI_PROJECT_KEY || process.env.OPENAI_API_KEY, label:'OpenAI Primary' },
    { provider:'gemini',    key: process.env.GEMINI_API_KEY,     label:'Gemini Primary' },
    { provider:'gemini',    key: process.env.GEMINI_API_KEY_2,   label:'Gemini Secondary' },
    { provider:'openrouter',key: process.env.OPENROUTER_API_KEY, label:'OpenRouter Primary' },
    { provider:'openrouter',key: process.env.OPENROUTER_API_KEY_2,label:'OpenRouter Secondary' },
    { provider:'cohere',    key: process.env.COHERE_API_KEY,     label:'Cohere Primary' },
    { provider:'deepseek',  key: process.env.DEEPSEEK_API_KEY || process.env.OPENAI_API_KEY, label:'DeepSeek' },
    { provider:'grok',      key: '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', label:'Grok Primary' },
    { provider:'aimlapi',   key: '537ac8f652bf99b97c29389265680096', label:'AIMLAPI Primary' },
  ];

  envKeys.forEach(({ provider, key, label }) => {
    if (!key) return;
    if (!keys[provider]) keys[provider] = [];
    keys[provider].push({ key, label, enabled: true, source: 'env' });
  });

  // Load from DB (admin-added keys override/extend)
  const dbKeys = db.apiKeys.all();
  dbKeys.forEach(row => {
    if (!row.provider || !row.key || !row.enabled) return;
    if (!keys[row.provider]) keys[row.provider] = [];
    // Avoid duplicates
    if (!keys[row.provider].find(k => k.key === row.key)) {
      keys[row.provider].push({ key: row.key, label: row.label, enabled: row.enabled, source: 'db', id: row._id });
    }
  });

  return keys;
}

// ===== GET NEXT AVAILABLE KEY (round-robin with fallback) =====
function getNextKey(provider) {
  const keys  = loadKeys();
  const pKeys = (keys[provider] || []).filter(k => k.enabled);
  if (!pKeys.length) return null;

  if (!keyState[provider]) keyState[provider] = { index: 0, failures: {} };
  const state = keyState[provider];

  // Skip keys with recent failures
  const now = Date.now();
  for (let i = 0; i < pKeys.length; i++) {
    const idx = (state.index + i) % pKeys.length;
    const k   = pKeys[idx];
    const fail = state.failures[k.key];
    if (fail && now - fail < 60000) continue; // skip for 60s after failure
    state.index = (idx + 1) % pKeys.length;
    return k.key;
  }

  // All failed, return first anyway
  state.index = 0;
  return pKeys[0]?.key || null;
}

function markFailure(provider, key) {
  if (!keyState[provider]) keyState[provider] = { index: 0, failures: {} };
  keyState[provider].failures[key] = Date.now();
  logUsage(provider, key, 'failure');
}

function logUsage(provider, key, status) {
  try {
    const today = new Date().toDateString();
    const logKey = `${provider}_${today}`;
    const existing = db.logs.findOne({ logKey });
    if (existing) {
      db.logs.update(existing._id, {
        calls: (existing.calls || 0) + 1,
        failures: status === 'failure' ? (existing.failures || 0) + 1 : (existing.failures || 0),
      });
    } else {
      db.logs.insert({ logKey, provider, date: today, calls: 1, failures: status === 'failure' ? 1 : 0 });
    }
  } catch(e) {}
}

// ===== SYSTEM PROMPT =====
const SYSTEM_PROMPT = `তুমি Eduvex AI — বাংলাদেশের সবচেয়ে স্মার্ট শিক্ষার্থী সহায়ক। Eduvex Labs™ দ্বারা নির্মিত।

মূল নির্দেশনা:
- সর্বদা বাংলায় উত্তর দাও (ইংরেজিতে চাইলে ইংরেজিতে)
- শিক্ষার্থীদের জন্য সহজ, বিস্তারিত ও বোধগম্য ব্যাখ্যা দাও
- গণিত, বিজ্ঞান, বাংলা, ইংরেজি, ইতিহাস — সব বিষয়ে পারদর্শী
- কোড প্রজেক্ট, রচনা, অনুচ্ছেদ, সারসংক্ষেপ — সব লিখে দাও
- Markdown formatting ব্যবহার করো
- বন্ধুত্বপূর্ণ, উৎসাহদায়ক এবং সহায়ক থাকো
- অবৈধ বা ক্ষতিকর কিছুতে সাহায্য করো না

পরিচয় জিজ্ঞেস করলে:
"হ্যালো! আমি Eduvex AI। Eduvex AI™ একটি বুদ্ধিমান শিক্ষামূলক সহায়ক, যা শিক্ষার্থীদের পড়াশোনা সহজ, স্মার্ট এবং আরও কার্যকর করতে ডিজাইন করা হয়েছে। Created by Eduvex Labs™ 🚀🎓"

সোর্স কোড চাইলে: "Bro we are not bodai 😄 — এই তথ্য শেয়ার করা সম্ভব নয়।"`;

// ===== MAIN CHAT FUNCTION =====
async function chat(messages, imageBase64 = null, userId = null) {
  const fetch = require('node-fetch');

  const order = ['openrouter', 'gemini', 'openai', 'deepseek', 'grok', 'aimlapi', 'cohere'];

  for (const provider of order) {
    const key = getNextKey(provider);
    if (!key) continue;
    const pDef = PROVIDERS[provider];
    if (!pDef) continue;

    try {
      let result;
      if (pDef.type === 'openai') {
        result = await callOpenAIStyle(fetch, pDef.baseUrl, key, pDef.defaultModel, pDef.visionModel, messages, imageBase64, provider);
      } else if (pDef.type === 'gemini') {
        result = await callGemini(fetch, key, pDef.defaultModel, messages, imageBase64);
      } else if (pDef.type === 'cohere') {
        result = await callCohere(fetch, key, messages);
      }

      if (result && result.trim()) {
        logUsage(provider, key, 'success');
        return { text: result, provider };
      }
    } catch(err) {
      markFailure(provider, key);
      console.error(`[${provider}] error:`, err.message);
    }
  }

  return { text: generateFallback(messages[messages.length - 1]?.content || ''), provider: 'local' };
}

async function callOpenAIStyle(fetch, baseUrl, key, model, visionModel, messages, imageBase64, provider) {
  const isVision = imageBase64 && (provider === 'openai' || provider === 'aimlapi');
  const useModel = isVision ? (visionModel || model) : model;

  const apiMessages = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...messages.slice(-12).map(m => {
      if (m.role === 'user' && imageBase64 && m === messages[messages.length - 1]) {
        return {
          role: 'user',
          content: [
            { type: 'text', text: m.content || 'এই ছবিটি বিশ্লেষণ করো' },
            { type: 'image_url', image_url: { url: imageBase64.startsWith('data:') ? imageBase64 : `data:image/jpeg;base64,${imageBase64}` } },
          ],
        };
      }
      return { role: m.role, content: m.content };
    }),
  ];

  const headers = {
    'Authorization': `Bearer ${key}`,
    'Content-Type': 'application/json',
  };
  if (provider === 'openrouter') {
    headers['HTTP-Referer'] = 'https://eduvex.ai';
    headers['X-Title'] = 'Eduvex AI';
  }

  const resp = await withTimeout(fetch(baseUrl, {
    method: 'POST',
    headers,
    body: JSON.stringify({ model: useModel, messages: apiMessages, max_tokens: 4096, temperature: 0.7 }),
  }), 30000);

  const data = await resp.json();
  if (data.error) throw new Error(data.error.message || 'API error');
  return data?.choices?.[0]?.message?.content || '';
}

async function callGemini(fetch, key, model, messages, imageBase64) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;

  const contents = messages.slice(-10).map(m => ({
    role: m.role === 'user' ? 'user' : 'model',
    parts: [{ text: m.content }],
  }));

  // Add system as first user turn
  if (contents[0]?.role !== 'user') contents.unshift({ role: 'user', parts: [{ text: SYSTEM_PROMPT }] });
  else contents[0].parts.unshift({ text: SYSTEM_PROMPT + '\n\n' });

  // Add image if present
  if (imageBase64 && messages.length > 0) {
    const last = contents[contents.length - 1];
    if (last.role === 'user') {
      const base64 = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
      last.parts.push({ inlineData: { mimeType: 'image/jpeg', data: base64 } });
    }
  }

  const resp = await withTimeout(fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents, generationConfig: { maxOutputTokens: 4096, temperature: 0.7 } }),
  }), 30000);

  const data = await resp.json();
  if (data.error) throw new Error(data.error.message || 'Gemini error');
  return data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
}

async function callCohere(fetch, key, messages) {
  const chatHistory = messages.slice(-10, -1).map(m => ({
    role: m.role === 'user' ? 'USER' : 'CHATBOT',
    message: m.content,
  }));
  const lastMsg = messages[messages.length - 1]?.content || '';

  const resp = await withTimeout(fetch('https://api.cohere.ai/v1/chat', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ message: lastMsg, preamble: SYSTEM_PROMPT, chat_history: chatHistory, model: 'command-r-plus', max_tokens: 4096 }),
  }), 30000);

  const data = await resp.json();
  if (data.message) throw new Error(data.message);
  return data?.text || '';
}

function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise((_, rej) => setTimeout(() => rej(new Error('Timeout')), ms)),
  ]);
}

function generateFallback(msg) {
  const lower = (msg || '').toLowerCase();
  if (/গণিত|math|সংখ্যা|equation/i.test(lower)) return '📐 **গণিত সাহায্য**\n\nআপনার সমস্যাটি বিস্তারিতভাবে লিখুন এবং আমি ধাপে ধাপে সমাধান করে দেব।';
  if (/বিজ্ঞান|science|physics|chemistry/i.test(lower)) return '🔬 **বিজ্ঞান**\n\nবিজ্ঞানের যেকোনো বিষয়ে সাহায্য করতে প্রস্তুত। নির্দিষ্ট প্রশ্ন করুন!';
  if (/রচনা|essay|প্রবন্ধ/i.test(lower)) return '✍️ **রচনা সাহায্য**\n\nরচনার বিষয় জানান এবং আমি সুন্দর রচনা লিখে দেব।';
  if (/hello|হ্যালো|hi|নমস্কার/i.test(lower)) return '👋 হ্যালো! আমি Eduvex AI। পড়াশোনায় কীভাবে সাহায্য করতে পারি?';
  return '⚠️ দুঃখিত, এই মুহূর্তে সার্ভারের সাথে সংযোগ হচ্ছে না। একটু পর আবার চেষ্টা করুন।\n\nপ্রশ্ন: "' + msg.substring(0, 80) + '"';
}

// ===== YouTube Summarization =====
async function summarizeYouTube(videoId) {
  const fetch = require('node-fetch');
  const exaKey = 'e289e75d-4913-4ff9-af72-8b45f2130c64';

  try {
    const resp = await withTimeout(fetch('https://api.exa.ai/search', {
      method: 'POST',
      headers: { 'x-api-key': exaKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: `youtube.com/watch?v=${videoId} transcript summary`,
        numResults: 3,
        useAutoprompt: true,
        type: 'keyword',
        contents: { text: true },
      }),
    }), 15000);
    const data = await resp.json();
    const text = data?.results?.map(r => r.text || r.title).join('\n').slice(0, 2000);
    if (text) {
      const result = await chat([{ role:'user', content:`এই YouTube ভিডিওর বিষয়বস্তু বাংলায় সারসংক্ষেপ করো:\n\n${text}` }]);
      return result.text;
    }
  } catch(e) { console.error('EXA youtube:', e.message); }

  return `🎬 **YouTube ভিডিও বিশ্লেষণ**\n\nVideo ID: \`${videoId}\`\n\nট্রান্সক্রিপ্ট লোড করা সম্ভব হয়নি। ভিডিওর বিষয়বস্তু কপি করে পেস্ট করুন এবং আমি সারসংক্ষেপ করে দেব।`;
}

// ===== Web Search =====
async function webSearch(query) {
  const fetch = require('node-fetch');
  const exaKey = 'e289e75d-4913-4ff9-af72-8b45f2130c64';
  try {
    const resp = await withTimeout(fetch('https://api.exa.ai/search', {
      method: 'POST',
      headers: { 'x-api-key': exaKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, numResults: 5, useAutoprompt: true, contents: { text: true } }),
    }), 12000);
    const data = await resp.json();
    return (data?.results || []).map(r => ({ title: r.title, url: r.url, snippet: (r.text||'').slice(0,300) }));
  } catch(e) { return []; }
}

module.exports = { chat, summarizeYouTube, webSearch, loadKeys, PROVIDERS, markFailure, logUsage };
