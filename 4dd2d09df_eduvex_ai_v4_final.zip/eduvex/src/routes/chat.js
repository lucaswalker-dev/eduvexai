const express = require('express');
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');
const { requireAuth } = require('../middleware/auth');
const db      = require('../models/db');
const api     = require('../services/apiManager');

const router = express.Router();

// Multer for image uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('Only images allowed'), false);
  },
});

// ===== GET all chats for user =====
router.get('/', requireAuth, (req, res) => {
  const chats = db.chats.find({ userId: req.user._id })
    .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  res.json({ chats });
});

// ===== CREATE new chat =====
router.post('/', requireAuth, (req, res) => {
  const { title } = req.body;
  const chat = db.chats.insert({ userId: req.user._id, title: title || 'নতুন চ্যাট', messageCount: 0 });
  res.json({ chat });
});

// ===== GET messages of a chat =====
router.get('/:chatId/messages', requireAuth, (req, res) => {
  const chat = db.chats.findById(req.params.chatId);
  if (!chat || chat.userId !== req.user._id) return res.status(404).json({ error: 'Chat not found' });
  const messages = db.messages.find({ chatId: req.params.chatId })
    .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
  res.json({ messages, chat });
});

// ===== SEND message + get AI response =====
router.post('/:chatId/messages', requireAuth, upload.single('image'), async (req, res) => {
  try {
    const { content, webSearch: doWebSearch, youtubeUrl } = req.body;
    const chatId = req.params.chatId;

    let chat = db.chats.findById(chatId);
    if (!chat) {
      chat = db.chats.insert({ _id: chatId, userId: req.user._id, title: 'নতুন চ্যাট', messageCount: 0 });
    }
    if (chat.userId !== req.user._id) return res.status(403).json({ error: 'Forbidden' });

    // Handle image
    let imageBase64 = null;
    if (req.file) {
      const mime = req.file.mimetype;
      imageBase64 = `data:${mime};base64,${req.file.buffer.toString('base64')}`;
    }

    // Save user message
    const userMsg = db.messages.insert({
      chatId, userId: req.user._id,
      role: 'user', content: content || '',
      hasImage: !!imageBase64,
    });

    // Update chat title (first message)
    const msgCount = db.messages.find({ chatId }).length;
    if (msgCount <= 2 && content) {
      db.chats.update(chatId, { title: content.substring(0, 50) + (content.length > 50 ? '…' : '') });
    }
    db.chats.update(chatId, { messageCount: msgCount, updatedAt: new Date().toISOString() });

    // Build conversation history
    const history = db.messages.find({ chatId })
      .sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
      .slice(-12)
      .map(m => ({ role: m.role, content: m.content || '' }));

    let aiText = '';
    let searchResults = null;

    // YouTube summarization
    const ytMatch = (content || '').match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/);
    if (ytMatch) {
      aiText = await api.summarizeYouTube(ytMatch[1]);
    }
    // Web search
    else if (doWebSearch === 'true' || doWebSearch === true) {
      searchResults = await api.webSearch(content);
      if (searchResults && searchResults.length > 0) {
        const ctx = searchResults.map(r => `**${r.title}**\n${r.snippet}\nSource: ${r.url}`).join('\n\n');
        const augHistory = [...history.slice(0, -1), { role: 'user', content: `Web search results:\n${ctx}\n\nUser question: ${content}` }];
        const res2 = await api.chat(augHistory, imageBase64, req.user._id);
        aiText = res2.text;
      } else {
        const r = await api.chat(history, imageBase64, req.user._id);
        aiText = r.text;
      }
    }
    // Normal chat
    else {
      const r = await api.chat(history, imageBase64, req.user._id);
      aiText = r.text;
    }

    // Save AI message
    const aiMsg = db.messages.insert({
      chatId, userId: req.user._id,
      role: 'assistant', content: aiText,
      searchResults: searchResults || null,
    });

    db.chats.update(chatId, { messageCount: msgCount + 1, updatedAt: new Date().toISOString() });

    res.json({ userMessage: userMsg, aiMessage: aiMsg, chat: db.chats.findById(chatId) });
  } catch(e) {
    console.error('Chat error:', e);
    res.status(500).json({ error: 'AI response error: ' + e.message });
  }
});

// ===== DELETE chat =====
router.delete('/:chatId', requireAuth, (req, res) => {
  const chat = db.chats.findById(req.params.chatId);
  if (!chat || chat.userId !== req.user._id) return res.status(404).json({ error: 'Not found' });
  db.chats.delete(req.params.chatId);
  db.messages.find({ chatId: req.params.chatId }).forEach(m => db.messages.delete(m._id));
  res.json({ success: true });
});

// ===== UPDATE chat title =====
router.patch('/:chatId', requireAuth, (req, res) => {
  const chat = db.chats.findById(req.params.chatId);
  if (!chat || chat.userId !== req.user._id) return res.status(404).json({ error: 'Not found' });
  db.chats.update(req.params.chatId, { title: req.body.title || chat.title });
  res.json({ success: true });
});

module.exports = router;
