const express  = require('express');
const bcrypt   = require('bcryptjs');
const fetch    = require('node-fetch');
const db       = require('../models/db');
const { signToken, requireAuth } = require('../middleware/auth');

const router = express.Router();

const TG_TOKEN   = process.env.TELEGRAM_BOT_TOKEN_2 || '';
const TG_CHAT_ID = '7254596182';

async function sendTelegram(text) {
  if (!TG_TOKEN) return;
  try {
    await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: TG_CHAT_ID, text, parse_mode: 'HTML' }),
    });
  } catch(e) { console.error('Telegram error:', e.message); }
}

// POST /api/auth/signup
router.post('/signup', async (req, res) => {
  try {
    const { name, age, district, school, className, email, password } = req.body;
    if (!name || !email || !password || !district || !school || !className) {
      return res.status(400).json({ error: 'সকল তথ্য পূরণ করুন' });
    }
    if (password.length < 6) return res.status(400).json({ error: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে' });
    if (db.users.findOne({ email: email.toLowerCase() })) {
      return res.status(400).json({ error: 'এই ইমেইলে ইতিমধ্যে একটি অ্যাকাউন্ট আছে' });
    }

    const hashed = await bcrypt.hash(password, 12);
    const user = db.users.insert({
      name, age, district, school,
      className, email: email.toLowerCase(),
      password: hashed, role: 'user',
    });

    // Track daily signups
    const today = new Date().toDateString();
    const stat = db.stats.findOne({ type: 'signups', date: today });
    if (stat) db.stats.update(stat._id, { count: (stat.count || 0) + 1 });
    else db.stats.insert({ type: 'signups', date: today, count: 1 });

    // Telegram notification
    const tgMsg = `🎓 <b>New Eduvex AI Registration!</b>\n\n` +
      `👤 নাম: ${name}\n🎂 বয়স: ${age}\n📍 জেলা: ${district}\n` +
      `🏫 প্রতিষ্ঠান: ${school}\n📚 ক্লাস: ${className}\n📧 ইমেইল: ${email}\n` +
      `🕐 সময়: ${new Date().toLocaleString('en-BD')}\n\nPowered by Eduvex Labs™ 🚀`;
    sendTelegram(tgMsg);

    const token = signToken({ id: user._id, role: 'user' });
    res.cookie('eduvex_token', token, { httpOnly: true, maxAge: 30 * 86400000, sameSite: 'lax' });

    const { password: _, ...safeUser } = user;
    res.json({ success: true, user: safeUser, token });
  } catch(e) {
    console.error('Signup error:', e);
    res.status(500).json({ error: 'সার্ভার ত্রুটি হয়েছে' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'ইমেইল ও পাসওয়ার্ড দিন' });

    const user = db.users.findOne({ email: email.toLowerCase() });
    if (!user) return res.status(401).json({ error: 'ইমেইল বা পাসওয়ার্ড ভুল' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'ইমেইল বা পাসওয়ার্ড ভুল' });

    // Track logins
    const today = new Date().toDateString();
    const stat = db.stats.findOne({ type: 'logins', date: today });
    if (stat) db.stats.update(stat._id, { count: (stat.count || 0) + 1 });
    else db.stats.insert({ type: 'logins', date: today, count: 1 });

    const token = signToken({ id: user._id, role: user.role || 'user' });
    res.cookie('eduvex_token', token, { httpOnly: true, maxAge: 30 * 86400000, sameSite: 'lax' });

    const { password: _, ...safeUser } = user;
    res.json({ success: true, user: safeUser, token });
  } catch(e) {
    res.status(500).json({ error: 'সার্ভার ত্রুটি' });
  }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  res.clearCookie('eduvex_token');
  res.clearCookie('eduvex_admin_token');
  res.json({ success: true });
});

// GET /api/auth/me
router.get('/me', requireAuth, (req, res) => {
  const { password: _, ...safeUser } = req.user;
  res.json({ user: safeUser });
});

module.exports = router;
