const express = require('express');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const db      = require('../models/db');
const { requireAdmin, signToken } = require('../middleware/auth');
const { loadKeys, PROVIDERS } = require('../services/apiManager');

const router = express.Router();

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@eduvex.ai';
const ADMIN_PASS  = process.env.ADMIN_PASS  || 'EduvexAdmin@2026#Ultra';
const JWT_SECRET  = process.env.JWT_SECRET  || 'EduvexAI_SecretKey_2026_Labs_Ultra_Secure_v4';

// ===== ADMIN LOGIN =====
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (email !== ADMIN_EMAIL || password !== ADMIN_PASS) {
    return res.status(401).json({ error: 'Invalid admin credentials' });
  }
  const token = jwt.sign({ role: 'admin', email }, JWT_SECRET, { expiresIn: '24h' });
  res.cookie('eduvex_admin_token', token, { httpOnly: true, maxAge: 86400000, sameSite: 'lax' });
  res.json({ success: true, token });
});

// ===== DASHBOARD STATS =====
router.get('/stats', requireAdmin, (req, res) => {
  const users     = db.users.all();
  const today     = new Date().toDateString();
  const yesterday = new Date(Date.now() - 86400000).toDateString();

  const todaySignups  = db.stats.find({ type:'signups',  date: today }).reduce((s,x)=>s+(x.count||0),0);
  const todayLogins   = db.stats.find({ type:'logins',   date: today }).reduce((s,x)=>s+(x.count||0),0);
  const logs          = db.logs.all();
  const totalApiCalls = logs.reduce((s,x)=>s+(x.calls||0),0);
  const todayApiCalls = logs.filter(l=>l.date===today).reduce((s,x)=>s+(x.calls||0),0);

  const apiBreakdown = {};
  logs.forEach(l => {
    if (!apiBreakdown[l.provider]) apiBreakdown[l.provider] = { calls:0, failures:0 };
    apiBreakdown[l.provider].calls    += l.calls || 0;
    apiBreakdown[l.provider].failures += l.failures || 0;
  });

  // Users by district
  const districtMap = {};
  users.forEach(u => { districtMap[u.district] = (districtMap[u.district]||0)+1; });

  res.json({
    totalUsers: users.length,
    todaySignups, todayLogins, totalApiCalls, todayApiCalls,
    apiBreakdown, districtMap,
    recentUsers: users.slice(-10).reverse().map(u => {
      const { password:_,...safe } = u; return safe;
    }),
    allUsers: users.map(u => { const{password:_,...s}=u;return s; }),
  });
});

// ===== GET ALL API KEYS =====
router.get('/apikeys', requireAdmin, (req, res) => {
  const dbKeys = db.apiKeys.all();
  const envKeys = [];
  const envMap = {
    openai:      process.env.OPENAI_PROJECT_KEY || process.env.OPENAI_API_KEY,
    gemini:      process.env.GEMINI_API_KEY,
    gemini2:     process.env.GEMINI_API_KEY_2,
    openrouter:  process.env.OPENROUTER_API_KEY,
    openrouter2: process.env.OPENROUTER_API_KEY_2,
    cohere:      process.env.COHERE_API_KEY,
    deepseek:    process.env.DEEPSEEK_API_KEY,
    grok:        'gsk_jYsh***[env]',
    aimlapi:     '537a***[env]',
  };
  Object.entries(envMap).forEach(([k,v]) => {
    if (v) envKeys.push({ _id:'env_'+k, provider: k.replace(/\d/,''), label: k+' (ENV)', key: v.substring(0,8)+'***', enabled:true, source:'env' });
  });

  // Mask keys from DB
  const masked = dbKeys.map(k => ({ ...k, key: k.key?.substring(0,8) + '***' }));
  res.json({ keys: [...envKeys, ...masked], providers: Object.keys(PROVIDERS) });
});

// ===== ADD API KEY =====
router.post('/apikeys', requireAdmin, (req, res) => {
  const { provider, key, label, priority } = req.body;
  if (!provider || !key) return res.status(400).json({ error: 'provider and key required' });
  const newKey = db.apiKeys.insert({ provider, key, label: label || provider, priority: priority || 0, enabled: true });
  res.json({ success: true, key: { ...newKey, key: newKey.key.substring(0,8)+'***' } });
});

// ===== UPDATE API KEY =====
router.patch('/apikeys/:id', requireAdmin, (req, res) => {
  const { label, enabled, priority, key } = req.body;
  const existing = db.apiKeys.findById(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  const update = {};
  if (label !== undefined) update.label = label;
  if (enabled !== undefined) update.enabled = enabled;
  if (priority !== undefined) update.priority = priority;
  if (key) update.key = key;
  db.apiKeys.update(req.params.id, update);
  res.json({ success: true });
});

// ===== DELETE API KEY =====
router.delete('/apikeys/:id', requireAdmin, (req, res) => {
  if (req.params.id.startsWith('env_')) return res.status(400).json({ error: 'Cannot delete env keys' });
  db.apiKeys.delete(req.params.id);
  res.json({ success: true });
});

// ===== TEST API KEY =====
router.post('/apikeys/test', requireAdmin, async (req, res) => {
  const { provider, key } = req.body;
  if (!key) return res.status(400).json({ error: 'key required' });
  try {
    const fetch = require('node-fetch');
    let ok = false;
    if (provider === 'gemini') {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${key}`);
      ok = r.ok;
    } else if (provider === 'openrouter' || provider === 'openai' || provider === 'deepseek' || provider === 'grok' || provider === 'aimlapi') {
      const baseUrls = {
        openai:'https://api.openai.com/v1/models',
        openrouter:'https://openrouter.ai/api/v1/models',
        deepseek:'https://api.deepseek.com/v1/models',
        grok:'https://api.x.ai/v1/models',
        aimlapi:'https://api.aimlapi.com/v1/models',
      };
      const r = await fetch(baseUrls[provider]||baseUrls.openai, { headers:{ Authorization:`Bearer ${key}` } });
      ok = r.ok;
    }
    res.json({ ok, provider });
  } catch(e) {
    res.json({ ok: false, error: e.message });
  }
});

// ===== GET ALL USERS =====
router.get('/users', requireAdmin, (req, res) => {
  const users = db.users.all().map(u => { const{password:_,...s}=u; return s; });
  res.json({ users });
});

// ===== DELETE USER =====
router.delete('/users/:id', requireAdmin, (req, res) => {
  db.users.delete(req.params.id);
  res.json({ success: true });
});

// ===== GET LOGS =====
router.get('/logs', requireAdmin, (req, res) => {
  const logs = db.logs.all().sort((a,b) => new Date(b.updatedAt) - new Date(a.updatedAt)).slice(0, 100);
  res.json({ logs });
});

// ===== CLEAR LOGS =====
router.delete('/logs', requireAdmin, (req, res) => {
  db.logs.all().forEach(l => db.logs.delete(l._id));
  res.json({ success: true });
});

module.exports = router;
