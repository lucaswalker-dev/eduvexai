/**
 * Eduvex AI Server — v4.0
 * Powered by Eduvex Labs™
 */
require('dotenv').config();
const express     = require('express');
const cookieParser= require('cookie-parser');
const cors        = require('cors');
const path        = require('path');
const helmet      = require('helmet');
const rateLimit   = require('express-rate-limit');

const authRoutes  = require('./src/routes/auth');
const chatRoutes  = require('./src/routes/chat');
const adminRoutes = require('./src/routes/admin');

const app  = express();
const PORT = process.env.PORT || 3000;

// Security
app.use(helmet({ contentSecurityPolicy: false }));
app.use(rateLimit({ windowMs: 15*60*1000, max: 300, message: { error: 'Too many requests' } }));
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));
app.use(cookieParser());

// Static files
app.use(express.static(path.join(__dirname, 'public')));
app.use('/data', express.static(path.join(__dirname, 'data')));

// API Routes
app.use('/api/auth',  authRoutes);
app.use('/api/chats', chatRoutes);
app.use('/api/admin', adminRoutes);

// Health check
app.get('/api/health', (req, res) => res.json({ status:'ok', version:'4.0.0', platform:'Eduvex AI by Eduvex Labs™' }));

// SPA fallback — serve index.html for all non-API routes
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  } else {
    res.status(404).json({ error: 'Not found' });
  }
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`\n🚀 Eduvex AI Server running on port ${PORT}`);
  console.log(`📚 Platform: Eduvex Labs™ v4.0`);
  console.log(`🔐 Admin: admin@eduvex.ai`);
  console.log(`🌐 Open: http://localhost:${PORT}\n`);
});

module.exports = app;
