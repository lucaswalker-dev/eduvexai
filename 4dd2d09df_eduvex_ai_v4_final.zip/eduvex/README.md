# Eduvex AI v4.0 — Complete Installation Guide
**Powered by Eduvex Labs™**

## 📁 Folder Structure
```
eduvex/
├── server.js              # Main Express server
├── package.json           # Dependencies
├── .env.example           # Environment variables template
├── .env                   # Your actual env (fill this in)
├── data/                  # Auto-created: JSON database files
│   ├── users.json
│   ├── chats.json
│   ├── messages.json
│   ├── apikeys.json
│   └── logs.json
├── public/                # Frontend (served as static)
│   ├── index.html         # Main app (single-page)
│   ├── css/style.css      # Complete ChatGPT-style CSS
│   └── js/app.js          # Frontend engine (no keys here)
└── src/
    ├── models/db.js        # Lightweight JSON database
    ├── middleware/auth.js  # JWT authentication
    ├── routes/
    │   ├── auth.js         # Signup / Login / Logout / Me
    │   ├── chat.js         # Chat CRUD + AI messaging
    │   └── admin.js        # Admin panel APIs
    └── services/
        └── apiManager.js   # Multi-API engine with fallback
```

## ⚡ Quick Start

### 1. Install Dependencies
```bash
cd eduvex
npm install
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env and add your API keys
nano .env
```

### 3. Run
```bash
# Development
node server.js

# Production (with PM2)
npm install -g pm2
pm2 start server.js --name eduvex-ai
pm2 startup && pm2 save
```

Open: http://localhost:3000

## 🔐 Admin Panel
- URL: http://localhost:3000/?admin=1
- Email: admin@eduvex.ai
- Password: EduvexAdmin@2026#Ultra
- **Change these in .env before deploying!**

## 🌐 Deploy to Render.com (Free)
1. Push to GitHub
2. New Web Service → connect repo
3. Build: `npm install`
4. Start: `node server.js`
5. Add all env variables in Render dashboard

## 🔑 API Keys Priority (auto fallback order)
1. OpenRouter (free DeepSeek R1)
2. Gemini 2.0 Flash
3. OpenAI GPT-4o
4. DeepSeek
5. Grok (xAI)
6. AIMLAPI
7. Cohere

## 🛡️ Security Features
- All API keys in .env (never in frontend)
- JWT HTTP-only cookies (30-day sessions)
- Helmet.js security headers
- Rate limiting (300 req/15min)
- Harmful content filtering
- Admin panel protected by separate token
- No source code leakage (devtools blocked)

## 📱 Mobile (Android)
- Input box stays visible on keyboard open
- Full responsive layout
- Voice input in Bangla (Chrome recommended)

## Version: 4.0.0 | © 2026 Eduvex Labs™
